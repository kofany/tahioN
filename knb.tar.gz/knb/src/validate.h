void validate(char *thisfile);
