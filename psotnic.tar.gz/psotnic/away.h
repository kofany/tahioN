#ifndef PSOTNIC_AWAY_H
#define PSOTNIC_AWAY_H 1

const char *bitchx_back[] = {
"O Romeo, Romeo! wherefore art thou Romeo?",
"A rose is a rose is a rose is a rose.",
"Seek, and ye shall find; knock, and it shall be opened unto you.",
"He that is without sin among you, let him cast the first stone.",
"Taxation without representation is tyranny.",
"He who can, does. He who cannot, teaches.",
"Lead us not into temptation, but deliver us from evil.",
"I think, therefore I am. (Cogito, ergo sum)",
"In the dark backward and abysm of time.",
"One from many. (E pluribus unum)",
NULL,
};

const char *bitchx_away[] = {
"(The heart has reasons of which reason has no knowledge.) [\002BX\002-MsgLog On]",
"(I only regret that I have but one life to lose for my country.) [\002BX\002-MsgLog On]",
"(Religion... Is the opium of the people.) [\002BX\002-MsgLog On]",
"(Earth to earth, ashes to ashes, dust to dust.) [\002BX\002-MsgLog On]",
"(Eye for eye, tooth for tooth, hand for hand, foot for foot.) [\002BX\002-MsgLog On]",
"(Every revolution was first a thought in one man's mind.) [\002BX\002-MsgLog On]",
"(Workers of the world, unite!) [\002BX\002-MsgLog On]",
"(What animal goes on 4 legs in the morning, 2 at noon, and 3 in the evening?) [\002BX\002-MsgLog On]",
"(Any road leads to the end of the world.) [\002BX\002-MsgLog On]",
"(Rome was not built in a day.) [\002BX\002-MsgLog On]",
NULL
};

const char *bitchx_away_add[] = {
"is away: ",
NULL
};

const char *bitchx_back_add[] = {
"is back. ",
NULL
};



const char *dzony_back[] = {
  "Los jest �lepy, ale trafia bez pud�a.",
  "Mniejsze z�o jest zwykle trwalsze.",
  "Nic tak nie m�czy jak cudzy wypoczynek.",
  "Piwo jest napojem ch�odz�cym zapa� do pracy.",
  "Przypadkowy bohater nigdy nie wspomina o przypadku.",
  "S�abym pozostaje tylko jedna bro�: b��dy silnych.",
  "Suma zer daje gro�n� liczb�.",
  "�mier� jest lekka. Tylko chwila przed zgonem jest straszna.",
  "Number Nine. Number Nine. Number Nine. Number Nine. Number Nine.",
  "Tragedia: miejsce, w kt�rym tch�rze umieraj�, a bohaterowie gin�.",
NULL
};

const char *dzony_away[] = {
  "O obecnych si� nie m�wi.",
  "W ciep�ym klimacie naj�atwiej wyrastaj� zimni dranie.",
  "W�dka pije ludzi do dna.",
  "Wyj�tki rozs�awiaj� regu��.",
  "Z�oty cielec jest tylko pewn� odmian� byd�a.",
  "�y� d�ugo chc� wszyscy, ale starym nikt nie chce by�.",
  "Brak wstrz�s�w powoduje niepok�j tw�rczy",
  "nie ma mnie. trupem pad�em.",
  "Demokracja: m�wisz, co chcesz, robisz, co ci ka��.",
  "Ekspert to cz�owiek, kt�ry przesta� my�le� - on wie.",
NULL
};

const char *dzony_away_add[] = {
"polazl. ",
NULL
};

const char *dzony_back_add[] = {
"powrocil. ",
NULL
};

const char *epic_back[] = {
  "... and back... and back...",
  "I'm back, but I may not be here long",
  "hi goober... oops wrong window!",
  "ok I'm here, now what were you saying?",
  "oh, I'm here allright! I've been purposely ignoring you",
  "And another thing... OOPS! BRB",
  "And if I had a brain I'd... I'd... I'd...",
  "I'm back",
  "so if A�+B�=C� why can't I ever find my car keys?",
  "You people make me sick!",
NULL
};

const char *epic_away[] = {
  "Working on my web page",
  "Out to eat with the family. BBL",
  "What diffrence does it make to you weither or not I'm here?",
  "When in doubt, beat the hell out of someone!",
  "Auto-Away after 10 mins",
  "Your preformance of a 'whois' has been logged",
  "Big Brother is watching you",
  "I'm here, I'm just ignoring you",
  "What did you want from me anyhow?",
  "I am working, I'm away, thats cause I have bills to pay!",
NULL
};

const char *epic_away_add[] = {
"is away. ",
NULL
};

const char *epic_back_add[] = {
"returned. ",
NULL
};

const char *irssi_back[] = {
  "that damn web page is driving me nuts",
  "check at http://www.windows95.com I think I saw one there",
  "and who let YOU in here?",
  "ok thats it! wait! I missed something!",
  "STAND BACK! this sucker might just blow!",
  "!ping ... !pong...",
  "!seen me..",
  "I was sexually assaulted by Bill Clinton!",
  "If I have to install windows on this machine ONE MORE TIME.... UGH!!",
  "You people think I'm back, but I've got you fooled!",
NULL
};

const char *irssi_away[] = {
  "Reading all that junk e-mail (who sends that shit anyhow?)",
  "browsing the web",
  "ACK!!",
  "Gone to pick up my kid. Be Right Back",
  "Gone to grab another 6 pack",
  "ABORT ABORT ABO....AHHHHHHHHH!!!!",
  "To page me press alt+F4",
  "Paying attention to my spouse (couldnt get out of it this time)",
  "IRC? Innovative Roach Clip?",
  "lookie at all the purty cullers, mahn",
  "BBL",
NULL
};

const char *irssi_away_add[] = {
"is gone. ",
NULL
};

const char *irssi_back_add[] = {
"is back. ",
NULL
};

const char *lice_back[] = {
"IRC ... more than an addiction ....",
"because i want to be bored !!!",
"and if you laugh, i'll kill you!",
"\"LiCe: The few, the proud, the elite!\"",
"what's up?  o/~",
"did i miss anything?",
"LiCe doesn't pick up BitchX, it picks up WhoreZ!",
"for more...lag...lameness...and net*cough*sex",
"please forgive me!",
"with beer and pretzels for everyone! (yeah right)",
NULL
};

const char *lice_away[] = {
"we'll be back after a few words from out sponsor.",
"idle is to perfection. away is to godliness.",
"recording messages. leave yours after the tone. *beep*",
"i am not here. please, leave a message.",
"practicing new lurking techniques.",
"bbl, feeding my kewl Lorry-Parrot",
"at class ... Advanced Idle Management 5060",
"can't you see that i am away?!",
"1 2 3 testing. can you see me?",
"stop whatever you are doing until i return.",
NULL
};

const char *lice_away_add[] = {
"is gone. ",
"is away. ",
NULL
};

const char *lice_back_add[] = {
"is back. ",
"returned. ",
NULL
};

const char *luzik_back[] = {
  "pi�kno zasmuca idiot�w, a cieszy m�drych.",
  "pope�nij z�y uczynek dwa razy, a przestaniesz go uwa�a� za grzech.",
  "najgorsze jest zepsucie najlepszego (zepsute najlepsze staje si� najgorszym).",
  "puste beczki wydaj� najg�o�niejsze d�wi�ki.",
  "do�wiadczenie to miano, kt�rym ka�dy okre�la swoje b��dy.",
  "niewielu mo�e nam pom�c, prawie ka�dy mo�e nam zaszkodzi�.",
  "daj mi ��ko i ksi��k�, a b�d� szcz�liwy.",
  "uczciwo�� to pi�kny klejnot, ale bardzo niemodny.",
  "nie lubi� zasad, wol� przes�dy.",
  "je�li do niczego nie d��ysz, nic nie osi�gniesz.",
NULL
};

const char *luzik_away[] = {
  "pracowito�� jest �r�d�em wszelkiej brzydoty.",
  "to podw�jna przyjemno�� oszuka� oszusta.",
  "trudno jest nie by� niesprawiedliwym dla osoby, kt�r� si� kocha.",
  "�atwo jest znosi� nieszcz�cia innych.",
  "m�dry to m�wca, kt�ry wie, kiedy nie ma nic do powiedzenia.",
  "daleka jest droga do celu.",
  "�ycie to szpital, w kt�rym ka�dy pacjent chce zmieni� ��ko.",
  "cz�owieka cz�sto bardziej denerwuj� drobiazgi ni� powa�ne rzeczy.",
  "ludzie m�cz� si� w pogoni za odpoczynkiem.",
  "w dzisiejszych czasach �piewa si� o tym, o czym nie warto m�wi�.",
NULL
};

const char *luzik_away_add[] = {
"powrocil. ",
NULL
};

const char *luzik_back_add[] = {
"zaginal. ",
NULL
};

const char *mirc_back[] = {
  "a fool must now and then be right by chance",
  "a gentleman is never rude, except on purpose",
  "a rich man can't imagine poverty",
  "do all the work you can: that is the whole philosophy of a good life",
  "evil is good perverted",
  "wspania�omy�lno�� jest istot� przyja�ni.",
  "ten, kto zakochuje si� sam w sobie, nie ma rywali.",
  "nigdy nie jest za p�no, �eby si� poprawi�.",
  "zachowaj pogod�, nie martw si�.",
  "ma�e umys�y rani� najmniejsze drobiazgi.",
NULL
};

const char *mirc_away[] = {
  "no one can be original by trying",
  "nothing is impossible in Russia but reform",
  "self-respect is at basis of good manners",
  "the character is a long standing habit",
  "there are so many things one can do without",
  "podziw to jedyny spos�b imitacji bez utraty oryginalno�ci.",
  "co nie jest po�yteczne dla nikogo, jest szkodliwe dla wszystkich.",
  "ziewanie jest przynajmniej szczer� opini�.",
  "m�odo�� to jedyna rzecz, kt�r� warto mie�.",
  "prawda jest zawsze paradoksalna..",
NULL
};

const char *mirc_away_add[] = {
"goes away. ",
NULL
};

const char *mirc_back_add[] = {
"is back. ",
NULL
};

const char *psotnic_back[] = {
  "Some moron is trying to nuke me!",
  "If anyone sees Larry, tell him I'll call him later",
  "\0032T\0033h\0034e\0035y\0036'\0037r\0038e \0039c\00310o\00311m\00312i\00313n\00314g \00313t\00312o \00311t\00310a\0039k\0038e \0037m\0036e \0035a\0034w\0033a\0032y \0031(\0032h\0033o \0034h\0035o\0036!\0037)\003",
  "Hold on people... this thing might just blow!",
  "she cant take much more! da ship's gonna blow up captain!",
  "I dunno, maybe diet Dr Pepper does taste more like regular Dr Pepper. Either way it SUCKS!",
  "so tell me about yourself-- name, age, sex, bank account number, etc",
  "Heck, if Bill Clinton can do it surely *I* can!",
  "Number Nine. Number Nine. Number Nine. Number Nine. Number Nine.",
  "Yo mamma!",
  "OK, That's it! I'm not doing ANY more!",
NULL
};

const char *psotnic_away[] = {
  "BRB",
  "Takin a good ole healthy dump",
  "snap crackle POP!",
  "Cleaning the wax outta my ears",
  "rooby, Rooby, ROO!!",
  "When in doubt, give in (she always wins anyhow!)",
  "takin a smoke break",
  "Having netsex with aliens (at least they SAID they were aliens)",
  "Can You see, that i'm away?!",
  "What? You need `.help'? :->",
NULL
};

const char *psotnic_away_add[] = {
"goes away. ",
NULL
};

const char *psotnic_back_add[] = {
"returned. ",
NULL
};
#endif
