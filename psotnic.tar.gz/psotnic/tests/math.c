#include <math.h>
#include <stdio.h>

int main()
{
	printf("%f\n", pow(10.0, 3.0));
	return 0;
}
